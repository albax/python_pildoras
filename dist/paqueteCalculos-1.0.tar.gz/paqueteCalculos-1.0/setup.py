from setuptools import setup
setup(
    name="paqueteCalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Al",
    author_email="axreddit.do@gmail.com",
    url="34.in",
    packages=["35_paquetes","35_paquetes.calculos.redondeo_potencia"
        
    ]
)