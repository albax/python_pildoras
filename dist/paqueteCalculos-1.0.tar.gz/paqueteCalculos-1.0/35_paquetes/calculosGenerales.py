###############################################
### 35 paquetes
### 
###############################################

#---------------------------------

def sumar(op1, op2):
    print("El resultado de la SUMA es: ", op1 + op2)

def restar(op1, op2):
    print("El resultado de la RESTAR es: ", op1 - op2)
    
def multiplicar(op1, op2):
    print("El resultado de la MULTIPLICAR es: ", op1 * op2)

def dividir(dividendo, divisor):
    print("El resultado de DIVIDIR es: ", dividendo / divisor)

def potenciar(base, exponente):
    print("El resultado de la POTENCIA es: ", base ** exponente)

def redondear(nro):
    print("El resultado de REDONDEAR es: ", round(nro))
